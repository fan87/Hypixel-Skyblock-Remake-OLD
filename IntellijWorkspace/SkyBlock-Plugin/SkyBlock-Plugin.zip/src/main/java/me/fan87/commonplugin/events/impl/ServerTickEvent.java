package me.fan87.commonplugin.events.impl;

public class ServerTickEvent {


}
